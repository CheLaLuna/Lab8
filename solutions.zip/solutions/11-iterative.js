const smallestDivisor = (num) => {
    // BEGIN
    if (num === 1){
      return 1;
    }
    else {
      for (let ND = 2; ND <= 100; ND++){
        if (num % ND === 0){
          return ND;
        };
      };
    };
    // END
    // ND -- NaimenshiyDelitel`
  };
export default smallestDivisor;
  