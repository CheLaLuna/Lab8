import _ from 'lodash';

// BEGIN
export function average(...nums){
    if (nums.length === 0){
        return null;
    }
    else {
        let averageNum = _.sum(nums)/nums.length;
        return averageNum;
    };
};
export default average;
// END