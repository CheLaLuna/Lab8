// BEGIN
export function getChildren(users) {
    return users.reduce((acc, user) => {
        return acc.concat(user.children);
    }, []).flat();
};
export default getChildren;
// END