import _ from 'lodash';

// BEGIN
export function takeOldest(users, count = 1){
    const sortedUsers = _.sortBy(users, user => Date.parse(user.birthday));
    return _.take(sortedUsers, count);
};
export default takeOldest;
// END