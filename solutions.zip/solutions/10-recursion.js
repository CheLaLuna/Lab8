const sequenceSum = (begin, end) => {
    // BEGIN
    if (begin === '' || end === '' || begin > end){
      return NaN;
    };
    if (begin === end){
      return begin;
    };
    let result = 0;
    for (let i = begin; i <= end; i++){
      result = result + i;
    };
    return result;
    // END
  };
export default sequenceSum;
  