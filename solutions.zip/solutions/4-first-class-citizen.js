const run = (text) => {
    // BEGIN
    function takeLast(text, n){
      if (text.length === 0 || text.length < n){
        return null;
      }
      else {
        return text.slice(-n).split('').reverse().join('');
      };
    // END
  };
  return takeLast(text, 4);
};
export default run;