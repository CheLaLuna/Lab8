// BEGIN
export function groupBy(array, mark){
    return array.reduce((acc, obj) => {
        const key = obj[mark];
        if (!acc[key]) {
            acc[key] = [];
        }
        acc[key].push(obj);
        return acc;
    }, {});
};
export default groupBy;
// END